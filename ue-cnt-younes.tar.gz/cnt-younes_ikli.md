## Préambule 


    Comme futur enseignant NSI ,je considére l'enseignement en classe inversé  un choix judicieux , les élèves apprennent les notions à la maison ,l ‘approfondissement ,les exercices et la correction seront en classe ,chaque élève à son rythme d’apprentissage ,ce qui amène à ne pas prévoir la même recette pour toute la classe .
    
  Le partage de ressources se fera via un site web (Moodle) accessible au publique (philosophie du logiciel libre), où les élèves reviendront à chaque fois se documenter et consulter les cours et exercices à faire ,l'espace privé avec authentification sera juste pour le rendement des travaux . 
  
  Le cours présenté dans ce document abordera les fonctions et les procédures en Python ,avec exemples et exercices d’applications , le document est à consulter à la maison ,pour mieux former les élèves à l’auto-formation ,tout en prévoyant la correction ,l’explication ,l’approfondissent, et le soutien en classe .
 
<img src="images/1.webp" >

# PYTHON - Les fonctions et les procédures
En Python, les fonctions et les procédures sont définis par le mot clé def. Le mot clé return permet de renvoyer une valeur. Une « vraie » fonction (au sens strict) doit en effet renvoyer une valeur (return) lorsqu’elle se termine.sinon si elle on a pas  un return c'est une procédure .

```python
def f(x):
    y = x + 1
    print("f(",x,")=",y)
    return y
f(5)

```

    f( 5 )= 6





    6


La syntaxe Python pour la définition d’une fonction/procédure est la suivante :

def nom_fonction(liste de paramètres):

      bloc d'instructions
      
      
      #pour les fonctions un return est obligatoire      
      return .....Procédure sans paramètre
Exemple :

```python
def compteur3():
    i = 0
    while i < 3:
        print(i)
        i = i + 1

compteur3()
```

    0
    1
    2

Exemple de table de multiplication de 7

```python
def table7():
    n = 1
    while n <11 :
        print(n ,"x", 7, "=" ,n*7,end ='\n')
        n = n +1
        

table7()
```

    1 x 7 = 7
    2 x 7 = 14
    3 x 7 = 21
    4 x 7 = 28
    5 x 7 = 35
    6 x 7 = 42
    7 x 7 = 49
    8 x 7 = 56
    9 x 7 = 63
    10 x 7 = 70

En entrant ces quelques lignes, nous avons défini une fonction( exactement Procédure) très simple qui calcule et affiche les 10 premiers termes de la table de multiplication par 7. Notez bien les parenthèses  , le double point, et l’indentation du bloc d’instructions qui suit la ligne d’en-tête (c’est ce bloc d’instructions qui constitue
le corps de la fonction/procédure proprement dite).
Pour utiliser la fonction que nous venons de définir, il suffit de l’appeler par son nom. Ainsi :

 table7()
## Exercices d'application :

(par abus de language on utulise  le mot fonction soit avec return ou sans ):

  1-Implémenter en python une fonction qui recoit un nombre en paramétre et qui affiche sa table de multiplication .
  
  2-déduire un programme qui affiche les tables de multiplication des nombre de 1 à 9.( fonction qui appelle une fonction ) .
   
  3-Impémenter en Python une fonction qui recoit un nombre en paramétre et qui affiche si il est paire ou impaire .
  
  4-Impémenter en Python une fonction qui recoit deux nombres en paramétres et qui affiche la soustraction avec condition quelle soit positive (le grand - le petit ).
  
  Notes : 
  
• Pour définir une fonction avec plusieurs paramètres, il suffit d’inclure ceux-ci entre les parenthèses qui suivent le nom de la fonction, en les séparant à l’aide de virgules.

 
##Utilisation des fonctions dans un script
Il est bien évident que les fonctions peuvent aussi s’utiliser dans des scripts. Veuillez donc essayer
vous-même le petit programme ci-dessous, lequel calcule le volume d’une sphère .

```python
def cube(n):
    return n**3
def volumeSphere(r):
    return 4 * 3.1416 * cube(r) / 3

r = input('Entrez la valeur du rayon : ')
print('Le volume de cette sphère vaut', volumeSphere(float(r)))
    
    
```

## Exercices :
1 -
   Définissez une fonction maximum(n1,n2,n3) qui renvoie le plus grand de 3 nombres n1, n2,n3 fournis en arguments. Par exemple, l’exécution de l’instruction :
print(maximum(2,5,4)) doit donner le résultat : 5.

2- 
Définissez une fonction compteMots(ph) qui renvoie le nombre de mots contenus dans la phrase ph. On considère comme mots les ensembles de caractères inclus entre des espaces.

NSI _ PG _ YOUNES IKLI 
